from __future__ import print_function
import os
import sys
import time
import datetime

import argparse
import collections
import random
import numpy as np


import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal


from tensorboardX import SummaryWriter
import yaml

sys.path.insert(0, "../learning/models/") 
sys.path.insert(0, "../robosuite/") 
sys.path.insert(0, "../learning/datalogging/") 
sys.path.insert(0, "../learning/supervised_learning/") 

from models import *
from logger import Logger

import robosuite
import robosuite.utils.transform_utils as T
from robosuite.wrappers import IKWrapper
from scipy.misc import imresize as resize

class ToTensor(object):
    """Convert ndarrays in sample to Tensors."""
    def __init__(self, device, key_list):
        self.device = device
        self.key_list = key_list

    def convert(self, sample):
        # convert numpy arrays to pytorch tensors
        new_dict = dict()
        for k, v in sample.items():
            if k in self.key_list:
                # print(v.shape)
                if k == "image":
                    v = np.rot90(v, k = 2)
                    v = resize(v, (128, 128))
                    v = np.transpose(v, (2, 1, 0))

                new_dict[k] = torch.from_numpy(v).float().to(device).unsqueeze(0).unsqueeze(1)

                # print(new_dict[k].size())

        return new_dict

def sample_gaussian(m, v, device):
    epsilon = Normal(0, 1).sample(m.size())
    return m + torch.sqrt(v) * epsilon.to(device)

class Generative_Action_Model(object):
    def __init__(self, num_steps, action_dim, mean, var, device, num_elite_samples):
        self.size = (num_steps, action_dim[0])
        self.mean = (torch.ones(self.size) * mean).to(device)
        self.var = (torch.ones(self.size) * var).to(device)
        self.device = device 
        self.nes = num_elite_samples
        self.obj_funct = nn.MSELoss(reduction = 'none')

    def sample(self, num_samples):
        return sample_gaussian(self.mean.unsqueeze(0).repeat(num_samples, 1, 1),\
            self.var.unsqueeze(0).repeat(num_samples, 1, 1), self.device)

    def cem_update(self, samples, pos, goal):
        scores = self.obj_funct(pos.cpu(), goal.cpu()).sum(1)
        sorted_scores, idxs = torch.sort(scores)

        self.mean = samples[idxs[:self.nes]].mean(dim = 0)
        self.var = samples[idxs[:self.nes]].var(dim = 0)

if __name__ == '__main__':
	#####################################################################
	### Loading run parameters
	#####################################################################
    with open("planning_params.yml", 'r') as ymlfile:
        cfg1 = yaml.safe_load(ymlfile)

    use_cuda = cfg1['evaluation_params']['use_GPU'] and torch.cuda.is_available()
    seed = cfg1['evaluation_params']['seed']

    debugging_val = cfg1['debugging_params']['debugging_val']

    model_folder = cfg1['evaluation_params']['model_folder']
    epoch_num = cfg1['evaluation_params']['epoch_num']

    parameters_path = cfg1['evaluation_params']['parameters_dictionary']

    num_samples = cfg1['evaluation_params']['num_samples']
    num_elite_samples = cfg1['evaluation_params']['num_elite_samples']
    num_steps = cfg1['evaluation_params']['num_steps'] 
    num_trials = cfg1['evaluation_params']['num_trials']
    num_iterations = cfg1['evaluation_params']['num_iterations']

    peg_type = cfg1['evaluation_params']['peg_type']

    with open(parameters_path, 'r') as ymlfile:
        cfg = yaml.safe_load(ymlfile)

    info_flow = cfg['info_flow']
    image_size = info_flow['dataset']['outputs']['image']
    force_size =info_flow['dataset']['outputs']['force'] 
    action_dim =info_flow['dataset']['outputs']['action']
    z_dim = cfg["model_params"]["z_dim"] 
    ##################################################################################
    ### Setting Debugging Flag
    ##################################################################################
    if debugging_val == 1.0:
        debugging_flag = True
        var = input("Debugging flag activated. No Results will be saved. Continue with debugging [y,n]: ")
        if var != "y":
            debugging_flag = False
    else:
        debugging_flag = False

    if debugging_flag:
        print("Currently Debugging")
    else:
        print("Training with debugged code")
    ##################################################################################
    ### Hardware and Low Level Training Details
    ##################################################################################
    device = torch.device("cuda" if use_cuda else "cpu")
    random.seed(seed)
    np.random.seed(seed)

    if use_cuda:
        torch.cuda.manual_seed(seed)
    else:
        torch.manual_seed(seed)

    if use_cuda:
      print("Let's use", torch.cuda.device_count(), "GPUs!")
    #################################################################################
    ### Defining and Loading Latent Space Encoder Model
    #################################################################################
    encoder = PlaNet_Multimodal(model_folder + "PlaNet_Multimodal", image_size, force_size, z_dim, action_dim, device = device).to(device)
    encoder.load(epoch_num)
    encoder.eval()
    ##################################################################################
    #### Logging tool to save scalars, images and models during training#####
    ##################################################################################
    save_model_flag = False
    logger = Logger(cfg1, debugging_flag, save_model_flag, device)
    logging_dict = {}
    logging_dict['scalar'] = {}
    logging_dict['image'] = []
    #################################################################################
    ### Loading Environment
    #################################################################################
    env = robosuite.make("SawyerPeg", has_renderer=True, ignore_done=True,\
     use_camera_obs=True, gripper_visualization=True, control_freq=100,\
      end_effector_type = peg_type + "_PegwForce")

    env = IKWrapper(env)
    obs = env.reset()
    # env.viewer.set_camera(camera_id=2)

    peg_bottom_site = peg_type + "_bottom_site"
    peg_top_site = peg_type + "_top_site"
    offset = np.array([0, 0, -0.045])
    goal = np.concatenate([env._get_sitepos(peg_top_site) + offset, np.array([np.pi, 0, np.pi])])
    obs_keys = [ "image", "force", "action_sequence"]
    to_tensor = ToTensor(device, obs_keys)

    tol = 0.001
    tol_ang = 0.003
    prev_time = time.time()
    for global_cnt in range(1, num_trials + 1):
        current_time = time.time()

        if global_cnt != 1:
            print("Trial took ", current_time - prev_time, " seconds")
            prev_time = time.time()

        env.set_robot_joint_positions([0, -1.18, 0.00, 2.18, 0.00, 0.57, 1.5708])

        while env._check_poserr(goal, tol, tol_ang) == False:
            action, action_euler = env._pd_6DOF_controller(goal)
            obs, reward, done, info = env.step(action)

        print("Reached Goal Position")

        goal_pos = obs['proprio'][:3]
        goal_z = encoder.encode(to_tensor.convert(obs))['latent_state']

        action_model = Generative_Action_Model(num_steps, action_dim, 0, 1, device, num_elite_samples)

        random_action_model = Generative_Action_Model(num_steps, action_dim, 0, 1, device, num_elite_samples)

        action_sequence = random_action_model.sample(1).squeeze().detach().cpu().numpy()

        for idx in range(action_sequence.shape[0]):
            action = env._clip_action(action_sequence[idx])
            obs, reward, done, info = env.step(action)

        init_pos = obs['proprio'][:3]

        tensor_obs = to_tensor.convert(obs)

        current_z = encoder.encode(to_tensor.convert(obs))['latent_state']
        dest_z = torch.zeros((num_samples, current_z.size(1)))

        for iteration in range(num_iterations):

            action_sequences = action_model.sample(num_samples)

            for idx in range(action_sequences.size(0)):
                action_sequence = action_sequences[idx]
                tensor_obs['action_sequence'] = action_sequence
                dest_z[idx]  = encoder.trans(tensor_obs)['latent_state']

            action_model.cem_update(action_sequences, dest_z, goal_z.repeat(num_samples, 1))

        opt_action_sequence = action_model.sample(1).squeeze().detach().cpu().numpy()

        for idx in range(opt_action_sequence.shape[0]):
            action = env._clip_action(opt_action_sequence[idx])
            obs, reward, done, info = env.step(action) 

        final_pos = obs['proprio'][:3]
        tensor_obs = to_tensor.convert(obs)
        current_z = encoder.encode(tensor_obs)['latent_state']

        if not debugging_flag:
            # print("Image size: ", encoder.get_image(current_z).size())
            # print("Image size: ", tensor_obs['image'][0].size())
            logging_dict['image'].append(encoder.get_image(current_z).squeeze())
            logging_dict['image'].append(tensor_obs['image'][0].squeeze())

            logging_dict['scalar']['distance_error'] = np.linalg.norm(final_pos - goal_pos)
            logging_dict['scalar']['distance_travelled'] = np.linalg.norm(final_pos - init_pos)
            logging_dict['scalar']['angular_error'] = np.arccos(np.dot(final_pos - init_pos, goal_pos - init_pos)\
             / (np.linalg.norm(final_pos - init_pos) * np.linalg.norm(goal_pos - init_pos)))

            logger.save_scalars(logging_dict, global_cnt, 'evaluation/')
            logger.save_images2D(logging_dict, global_cnt, 'evaluation/')

        if global_cnt % 10 == 0:
            print("Number of trials conducted: ", global_cnt)

    print("Finished Evaluation")













